<!DOCTYPE html>
<html>
	<head>
		<title>Employee Information Manager</title>
	</head>
<body>
	<h1 style="text-align:center">Employee Information<br>Manager</h1>
	
	<table border="1px" width="100%">
			<tr>
				<th><a href="home.php">View Feedback</a></td>
				<th><a href="InputFeedback.php">Input Feedback</a></td>
				<th><a href="ContuctUS.php">Contuct US</td>
			</tr>	
	</table>
	<br>
	
	<h3>About US:</h3>
	<p name="block"><b>Building a website is, in many ways, an exercise of willpower. It�s tempting to get distracted by the bells and whistles of the design process, and forget all about creating compelling content. But it's that last part that's crucial to making inbound marketing work for your business.</b></p>
	<h3>Detail:</h3>
	<img src="images.jpg" alt="image" width="300px" height="200px"/>
	<img src="images33.jpg" alt="image" width="300px" height="200px"/>
	<img src="pic1.jpg" alt="image" width="300px" height="200px"/>
		<br>
		<br>
		<br>
		<br>
		<br>
		<table border="1px" align="center" width="100%">
			<tr>
				<th>Footer</td>
			</tr
		</table>
	
</body>
</html>