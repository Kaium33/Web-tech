<!DOCTYPE html>
<html>
	<head>
		<title>Employee Information Manager</title>
	</head>
<body>
	<h1 style="text-align:center">Employee Information<br>Manager</h1>
	
	<table border="1px" width="100%">
			<tr>
				<th><a href="home.php">View Feedback</a></td>
				<th><a href="InputFeedback.php">Input Feedback</a></td>
				<th><a href="ContuctUS.php">Contuct US</td>
			</tr>	
	</table>
	<br>
	<br>
	<br>
	<br>
	<table border="1px" align="center" width="60%">
			<tr>
				<th>SL</td>
				<th>Emp ID</td>
				<th>Emp Name</td>
				<th>Rating</td>
				<th>Department</td>
			</tr>
			<tr>
				<th>1</td>
				<th>34</td>
				<th>abc</td>
				<th>1st class</td>
				<th>admin</td>
			</tr>
			<tr>
				<th>2</td>
				<th>345</td>
				<th>tgret</td>
				<th>ew</td>
				<th>admin</td>
			</tr>
			<tr>
				<th>3</td>
				<th>56</td>
				<th>gfh</td>
				<th>dfg</td>
				<th>admin</td>
			</tr>
			<tr>
				<th>4</td>
				<th>567</td>
				<th>dfg</td>
				<th>ghgf</td>
				<th>admin</td>
			</tr>
			<tr>
				<th>5</td>
				<th>SL NO</td>
				<th>name</td>
				<th>ID</td>
				<th>admin</td>
			</tr>
		</table>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<table border="1px" align="center" width="100%">
			<tr>
				<th>Footer</td>
			</tr
		</table>
	
</body>
</html>