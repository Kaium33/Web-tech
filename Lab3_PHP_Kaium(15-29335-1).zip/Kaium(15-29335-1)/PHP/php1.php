<!DOCTYPE html>
<html>
	<head>
		<title> my first php </title>
	</head>
	<body>
	<?php
		$name = "Abdul Kaium";
		$x = 1;
		$a = 10;
		$b = 20;
		
		define("hello","hello world..!!!",true);
		while($x <= 5){
			echo hello."<br>";
			$x++;
		}
		
		echo "<h2>"."For Loop:"."</h2>";
		for($z=1; $z<=10; $z++){
			echo "<h3>".$z.".".$name."</h3>";
		}
		
		
		
	?>
	</body>
</html>